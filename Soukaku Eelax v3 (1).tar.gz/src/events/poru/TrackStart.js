const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, StringSelectMenuBuilder,AttachmentBuilder, WebhookClient } = require("discord.js");
const AvonClientEvent = require(`../../structures/Eventhandler`);
const { ClassicPro } = require("musicard");
const fs = require("fs");
const moment = require(`moment`);
require(`moment-duration-format`);

class TrackStart extends AvonClientEvent {
    get name() {
        return 'playerStart';
    }

    async run(player, track) {
        // Create a webhook client
        const web1 = new WebhookClient({ url: "https://discord.com/api/webhooks/1188757723492401214/wKT4NI7WfxLNL8Gr5005pvHDAljy7Uk-4zpwRk7dmG4r66qkIE5faHPFlf_m_q8Swl4d" });

        // Get the server information
        const server = this.client.guilds.cache.get(player.guild);

        // Create and configure the embed
        const embed2 = new EmbedBuilder()
            .setColor(this.client.config.color)
            .setAuthor({ name: 'Player Started' }) // Fix: Pass an object to setAuthor
            .setDescription(`**Server :** [Cmds Log dekh](https://discord.gg/kxfvw8cHaA)] `);

        // Send the embed using the webhook client
        web1.send({ embeds: [embed2] });

        let url = track.uri;
        if (url.includes("youtube.com")) {
            url = this.client.config.server;
        }

        let mode = '';
        if (player.loop === `none`) mode = 'Off';
        if (player.loop === `track`) mode = `Track`;
        if (player.loop === `queue`) mode = 'Queue';

        let authorr = track.author;
        let album = track.title;
        let image = `${track.thumbnail ? track.thumbnail : `https://img.youtube.com/track/${track.identifier}/maxresdefault.jpg`}`;
        let requester = track.requester;

        const musicard = await ClassicPro({
            thumbnailImage: image,
            backgroundColor: "#070707",
            progress: 10,
            progressColor: "#AD23E8",
            progressBarColor: "#696969",
            name: album,
            nameColor: "#C4DCE8",
            author: authorr,
            authorColor: "#696969",
            startTime: "0:00",
            endTime: `3:69`,
            timeColor: "#FDF8FF"
        });

        fs.writeFileSync("musicard.png", musicard);

        const channel = this.client.channels.cache.get(player.textId);
        let duration = moment.duration(player.queue.current.length).format("hh:mm:ss");

        if (duration < 30) {
            player.skip();
            return channel.send({ embeds: [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.settings} I am skipping this track as its duration is less than 30 seconds`).setAuthor({ name: `Skip`, iconURL: track.requester.displayAvatarURL({ dynamic: true }) }).setTimestamp()] });
        }

        let but1 = new ButtonBuilder().setStyle(ButtonStyle.Success).setEmoji(`<:stop:1143765613702041612>`).setCustomId(`pl1`);
        let but2 = new ButtonBuilder().setStyle(ButtonStyle.Success).setEmoji(`<:pause:1143766597639606365>`).setCustomId(`pl2`);
        let but3 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:loop:1143766649644781599>`).setCustomId(`pl3`);
        let but4 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:previous:1143765653300445274>`).setCustomId(`pl4`);
        let but5 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:skip:1143766765063639172>`).setCustomId(`pl5`);
        let but6 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:astoria_volup:1193143905911308288>`).setCustomId(`pl6`);
        let but7 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:astoria_rewind:1193143591091052555>`).setCustomId(`pl7`);
        let but8 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:astoria_shuffle:1193143493544136775>`).setCustomId(`pl8`);
        let but9 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:astoria_forward:1193143726403498045>`).setCustomId(`pl9`);
        let but10 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:astoria_voldown:1193143831298846790>`).setCustomId(`pl10`);
        let ro = new ActionRowBuilder().addComponents(but4, but7, but2, but9, but5);
        let ro2 = new ActionRowBuilder().addComponents(but6, but3, but1, but8, but10);

        if (channel) {
            return channel?.send({ files: [musicard], components: [ro, ro2] }).then(x => player.data.set("music", x));
        }
    }
}

module.exports = TrackStart;
