const delay = require("delay");
const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require("discord.js");
const ArisaClientEvent= require("../../structures/Eventhandler");

class PlayerEmpty extends ArisaClientEvent{
    get name() {
        return 'playerEmpty';
    }

    async run(player) {
        
            
        let db = await this.client.data.get(`${player.guildId}-autoPlay`);
        if (!db || db === null) this.client.data.set(`${player.guildId}-autoPlay`, 'disabled');

        if (db === 'enabled') {
            let identifier = (player.queue.current && player.queue.current.identifier) || (player.queue.previous && player.queue.previous.identifier);

            if (identifier) {
                const search = `https://www.youtube.com/watch?v=${identifier}&list=RD${identifier}`;
                let result = await player.search(search, { requester: this.client.user });

                if (result && result.tracks && result.tracks.length > 0) {
                    player.queue.add(result.tracks[Math.floor(Math.random() * Math.floor(result.tracks.length))]);
                     player.data.get('music').delete()
                    player.play();
                }
            }
        }

        if (db === 'disabled') {
            let ch = this.client.channels.cache.get(player.textId);
            let guild = this.client.guilds.cache.get(player.guildId);
            let em = new EmbedBuilder().setColor(this.client.config.color).setAuthor({ name: 'Queue Ended', iconURL: guild.iconURL({ dynamic: true }) }). setDescription(`Add More Songs in Queue To Keep The Party Going`).setTimestamp();
            let but1 = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`${this.client.config.invite}`).setLabel(`Invite`).setEmoji(`${this.client.emoji.invite}`);
            let row = new ActionRowBuilder().addComponents(but1);
            player.data.get('music').delete()
            ch.send({ embeds: [em], components: [row] });
        }

        let data = await this.client.data.get(`${player.guildId}-247`);
        if (!data || data === null) this.client.data.set(`${player.guildId}-247`, 'disabled');

        if (data === 'enabled') return;

        if (data === 'disabled') {
            await delay(60000);
            player.destroy();
            let ch = this.client.channels.cache.get(player.textId);

            if (!ch) {
                let channel = await this.client.channels.fetch(player.textId);
                if (!channel) return;
                else ch = channel;
            }

            ch.send({
                embeds: [
                    new EmbedBuilder().setColor(this.client.config.color).setAuthor({ name: 'Player Destroyed' , iconURL: this.client.user.displayAvatarURL()}).setDescription(`Left Voice Channel Because Of Queue Ended / Inactive \n> Bypass This By Enabling 24/7 Mode`).setTimestamp()
                ]
            });
        }
        
    }
}

module.exports = PlayerEmpty;