const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle } = require("discord.js");
const AvonClientEvents = require(`../../structures/Eventhandler`);

class AvonInteractions extends AvonClientEvents{
    get name(){
        return 'interactionCreate';
    }
    async run(interaction,message,client){
    
        if(interaction.isButton())
        {
            try{
            let player = this.client.poru.players.get(interaction.guild.id);
            let botch = interaction.guild.members.me.voice.channel;
            let ch = interaction.member.voice.channel;
            if(interaction.customId === `pl1`)
            {
                if(interaction.message.id !== player.data.get('music').id)
                {
                    return interaction.message.delete();
                }
                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)
                {
                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})
                }
                else{
                    player.destroy();
                    return;
                }
            }
            if(interaction.customId === `pl2`)
            {
                if(interaction.message.id !== player.data.get('music').id)
                {
                    return interaction.message.delete();
                }
                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)
                {
                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})
                }
                else{
                    let but1 = new ButtonBuilder().setStyle(ButtonStyle.Success).setEmoji(`<:stop:1143765613702041612>`).setCustomId(`pl1`);
                    let but2 = new ButtonBuilder().setStyle(ButtonStyle.Success).setEmoji(!player.paused ? `<:resume:1147012983252320257>` : `<:pause:1143766597639606365>`).setCustomId(`pl2`);
                    let but3 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:loop:1143766649644781599>`).setCustomId(`pl3`);
                    let but4 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:previous:1143765653300445274>`).setCustomId(`pl4`);
                    let but5 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:skip:1143766765063639172>`).setCustomId(`pl5`);
                         let but6 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:astoria_volup:1193143905911308288>`).setCustomId(`pl6`);
                      let but7 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:astoria_rewind:1193143591091052555>`).setCustomId(`pl7`);
                      let but8 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:astoria_shuffle:1193143493544136775>`).setCustomId(`pl8`);
                      let but9 = new ButtonBuilder().setStyle(ButtonStyle.Primary).setEmoji(`<:astoria_forward:1193143726403498045>`).setCustomId(`pl9`);
                    let but10 = new ButtonBuilder().setStyle(ButtonStyle.Danger).setEmoji(`<:astoria_voldown:1193143831298846790>`).setCustomId(`pl10`);
                    let ro = new ActionRowBuilder().addComponents(but4,but7,but2,but9,but5);
                    let ro2 = new ActionRowBuilder().addComponents(but6,but3,but1,but8,but10);
                   player.pause(!player.paused);
                    return interaction.update({components : [ro, ro2]});
                }
            }
            if(interaction.customId === `pl3`)
            {
                if(interaction.message.id !== player.data.get('music').id)
                {
                    return interaction.message.delete();
                }
                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)
                {
                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})
                }
                else{
                    if(player.loop === `queue`)
                    {
                        player.setLoop(`none`);
                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | **Disabled** Looping`)],ephemeral : true});
                    }
                    else{
                        player.setLoop(`queue`);
                        return interaction.reply({embeds : [new EmbedBuilder().setDescription(`${this.client.emoji.tick} | **Enabled** Looping`).setColor(this.client.config.color)],ephemeral : true});
                    }
                }
            }
            if(interaction.customId === `pl4`)
            {
                if(interaction.message.id !== player.data.get('music').id)
                {
                    return interaction.message.delete();
                }
                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)
                {
                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})
                }
                else{
                    if(!player.queue.previous || player.queue.previous === null)
                    {
                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | No Previous song available.`)],ephemeral : true})
                    }
                    else{
                        player.queue.unshift(player.queue.previous);
                        player.skip();
                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | Playing previous track`)],ephemeral : true})
                    }
                }
            }
            if(interaction.customId === `pl5`)
            {
                if(interaction.message.id !== player.data.get('music').id)
                {
                    return interaction.message.delete();
                }
                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)
                {
                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})
                }
                else{
                    player.skip();
                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | **Skipped** the track`)],ephemeral : true})
                }
            }
    if(interaction.customId === `pl6`)

            {

                if(interaction.message.id !== player.data.get('music').id)

                {

                    return interaction.message.delete();

                }

                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)

                {

                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})

                }

                else{  
                    let vol = player.volume * 100 + 20/1;
        
                if(player.volume * 100 === 200){

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | Can't increase volume anymore.`)],ephemeral : true})

                    }

                    else{

                        player.setVolume(vol);

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | Players volume set to - \`${vol}%\``)],ephemeral : true})

                    }

                }

            }
                if(interaction.customId === `pl7`)

            {

                if(interaction.message.id !== player.data.get('music').id)

                {

                    return interaction.message.delete();

                }

                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)

                {

                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})

                }

                else{  

                    let time = player.position - 10000;

        

                if(player.paused){

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | Cant Rewind The Music when Paused.`)],ephemeral : true})

                    }

                    else{

                        player.seek(time);

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | Rewinded The Music.`)],ephemeral : true})

                    }

                }

            }
                if(interaction.customId === `pl8`)

            {

                if(interaction.message.id !== player.data.get('music').id)

                {

                    return interaction.message.delete();

                }

                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)

                {

                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})

                }

                else{  

                    let shuffle = player.queue.shuffle();

        

                if(player.queue.length === 0){

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | There are no songs in queue.`)],ephemeral : true})

                    }

                    else{

                      shuffle;  

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | Shuffled the Queue.`)],ephemeral : true})

                    }

                }

            }
                if(interaction.customId === `pl9`)

            {

                if(interaction.message.id !== player.data.get('music').id)

                {

                    return interaction.message.delete();

                }

                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)

                {

                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})

                }

                else{  

                let time2 = player.position + 10000;

        

                        if(player.paused){

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | Cant Forward The Music when Paused.`)],ephemeral : true})

                    }

                    else{

                        player.seek(time2);

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | Forwarded The Music.`)],ephemeral : true})

                    }

                }

            }
                    if(interaction.customId === `pl10`)

            {

                if(interaction.message.id !== player.data.get('music').id)

                {

                    return interaction.message.delete();

                }

                if(interaction.member.voice.channelId !== interaction.guild.members.me.voice.channelId)

                {

                    return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | You cannot use this button until connect to ${interaction.guild.members.me.voice.channel}`)],ephemeral : true})

                }

                else{  

                    let vol = player.volume * 100 - 20/1;

        

                if(player.volume * 100 === 0){

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.cross} | Can't decrease volume anymore.`)],ephemeral : true})

                    }

                    else{

                        player.setVolume(vol);

                        return interaction.reply({embeds : [new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.tick} | Players volume set to - \`${vol}%\``)],ephemeral : true})

                    }

                }

            }

   
                        
      }  catch(e) { console.log(e) }
  
    }
}}
module.exports = AvonInteractions;