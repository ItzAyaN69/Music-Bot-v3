const { EmbedBuilder , ButtonBuilder , ButtonStyle , ActionRowBuilder } = require(`discord.js`);
const AvonCommand = require("../../structures/avonCommand");

const moment = require(`moment`);

require(`moment-duration-format`);

class Uptime extends AvonCommand{

    get name(){

        return 'uptime';

    }

    get aliases(){

        return ['up']

    }

    get cat(){

        return 'info'

    }

    async run(client,message,args,prefix){

       let uptime = moment.duration(message.client.uptime).format(`D[days], H[hrs], m[mins], s[secs]`);

                let em = new EmbedBuilder().setDescription(`  **Last Reboot**  ${client.emoji.arrow} \`${uptime}\``).setAuthor({name : `Uptime`}).setTimestamp().setColor(client.config.color); 

        return message.channel.send({embeds : [em]});

    }

}

module.exports = Uptime;