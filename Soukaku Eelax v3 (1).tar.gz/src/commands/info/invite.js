const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class Invite extends AvonCommand{
    get name(){
        return 'invite'
    }
    get aliases(){
        return ['inv']
    }
    get cat(){
        return 'info';
    }
    async run(client,message,args,prefix)
    {
        let e = new EmbedBuilder().setColor(client.config.color).setDescription(`${this.client.emoji.invite} | Hey I Am Eelax 
A Complete Music  Bot. Click [here](${this.client.config.invite}) to [invite](${client.config.invite}) me.`).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setAuthor({name : `Invite`,iconURL : client.user.displayAvatarURL()}).setThumbnail(client.user.displayAvatarURL());
        let r = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`${client.config.invite}`).setLabel(`Invite`).setEmoji(`${this.client.emoji.invite}`)
        )
        return message.channel.send({embeds : [e] , components : [r]});
    }
}
module.exports = Invite;