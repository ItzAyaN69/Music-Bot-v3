const AvonCommand = require("../../structures/avonCommand");

const moment = require(`moment`);
const os = require(`os`);
const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require(`discord.js`);

class stats extends AvonCommand {

    get name() {

        return 'stats'

    }

    get aliases() {

        return ['botinfo', 'bi', 'about', 'statistics' ]

    }

    get cat() {

        return 'info'

    }

    async run(client,message,args,prefix){

        try{
            
    let users = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
    let guilds = client.guilds.cache.size;
   
    let ping = client.ws.ping;
    const uptime = moment.duration(client.uptime).format(" d [days], h [hrs], m [mins], s [secs]"); 
    let channel = client.channels.cache.size
    let voices = client.guilds.cache.reduce((acc, guild) => acc + guild.channels.cache.filter(channel => channel.type === 'GUILD_VOICE').size, 0);
    let stages = client.guilds.cache.reduce((acc, guild) => acc + guild.channels.cache.filter(channel => channel.type === 'GUILD_STAGE_VOICE').size, 0);

    const ayanpapa = await client.users.fetch("1081263937846263869");

    const embed = new EmbedBuilder()
      
      .setAuthor({
        name: message.author.username || "Unknown User",
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(`**[Official Support Server](${client.config.support})**`)
      .addFields(

            { name: '<:commands:1205395420042240050> __Botinfo__', value: `**Uptime:** ${uptime}\n**Guilds:** ${guilds}\n**Users:** ${users}\n**Ping:** ${ping}\n**Commands:** 69\n **Channels:** ${channel} `},

/*            { name: '<:commands:1205395420042240050> __Channels__', value: `<:channel:1204581390750974053> ${channel}|<:vc:1204581527942598696> ${voices}|<:stage:1204581474314227712> ${stages}`}*/
        )
      .setTimestamp();

    const Eelax = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setStyle(ButtonStyle.Success).setCustomId(`info`).setLabel(`Bot Info`).setDisabled(true),
      new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`cpu`).setLabel(`Team Info`),
      new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`links`).setLabel(`Links`)
    );

    const Eelax2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`info`).setLabel(`Bot Info`),
      new ButtonBuilder().setStyle(ButtonStyle.Success).setCustomId(`cpu`).setLabel(`Team Info`).setDisabled(true),
      new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`links`).setLabel(`Links`)
    );

    const Eelax3 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`info`).setLabel(`Bot Info`),
      new ButtonBuilder().setStyle(ButtonStyle.Secondary).setCustomId(`cpu`).setLabel(`Team Info`),
      new ButtonBuilder().setStyle(ButtonStyle.Success).setCustomId(`links`).setLabel(`Links`).setDisabled(true)
    );

    const msg = await message.channel.send({ embeds: [embed], components: [Eelax] });

    const ayan = await client.users.fetch("1081263937846263869");
    const manasbaccha = await client.users.fetch("959315653595131964");
    const tamim = await client.users.fetch("1053918356375351386");
    const ayush = await client.users.fetch("1051806381461745664");
    let embed1 = new EmbedBuilder()
      .setDescription(`**[Official Support Server](https://discord.gg/tmkc)**`)
      .addFields([
        { name: `<:commands:1205395420042240050> **__Team Of Eelax Music__**`, value: `<:Eelax_dot:1201446902290456636> [AyaN_xD](https://discord.com/users/1081263937846263869) - **Owner** [<:owner:1204739633980768306>]\n<:Eelax_dot:1201446902290456636> [Manas](https://discord.com/users/959315653595131964) - **Owner** [<:owner:1204739633980768306>]\n<:Eelax_dot:1201446902290456636> [Knifecodez](https://discord.com/users/1053918356375351386) - **Owner** [<:owner:1204739633980768306>]\n<:Eelax_dot:1201446902290456636> [Ayush_xD](https://discord.com/users/1051806381461745664) - **Owner** [<:owner:1204739633980768306>]\n<:Eelax_dot:1201446902290456636> [Ozuma_xD](https://discord.com/users/1029065620878282792) - **Owner** [<:owner:1204739633980768306>]`, inline: false }
      ])
      .setAuthor({
        name: message.author.username || "Unknown User",
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();

    const collector = await msg.createMessageComponentCollector({
      filter: (interaction) => {
        if (message.author.id === interaction.user.id) return true;
        else {
          interaction.reply({ content: `Only <@${message.author.id}> can use this button!`, ephemeral: true });
        }
      },
      time: 1000000,
      idle: 1000000 / 2
    });

    collector.on('collect', async (interaction) => {
      if (interaction.isButton()) {
        if (interaction.customId === `info`) {
          return interaction.update({ embeds: [embed], components: [Eelax] });
        }
        if (interaction.customId === `cpu`) {
          return interaction.update({ embeds: [embed1], components: [Eelax2] });
        }
        if (interaction.customId === `links`) {
          // Add embed for links button here
          const linksEmbed = new EmbedBuilder()
      
            .setAuthor({
        name: message.author.username || "Unknown User",
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setDescription(`**[Official Support Server](https://discord.gg/tmkc)**`)
            .addFields({ name: `<:commands:1205395420042240050> **__Links__**`, value: `<:invite:1204587724494078022> • **Invite Link:** [Invite](${client.config.invite})\n<:support:1204586806360801280> • **Support Server Link:** [Support](${client.config.support})\n<:privacypolicy:1204586982609518684> • **Privacy Policy Link:** [Privacy Policy](${client.config.privacy})\n<:vote:1204586591696195617> • **Vote Link:** [Coming Soon](${client.config.support})` });

          return interaction.update({ embeds: [linksEmbed], components: [Eelax3] });
        }
      }
    });

    collector.on('end', async () => {
      msg.edit({ content: ``, embeds: [embed], components: [], content : `Timed Out!`});
    });
    } catch(e) { console.log(e) }

} 

}

module.exports = stats;
