const { PermissionsBitField, EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand")

class twentyfourseven extends AvonCommand{
    get name(){
        return '247';
    }
    get aliases(){
        return ['24-7','twentyfourseven','alwaysvc','24/7']
    }
    get vote(){
        return false;
    }
    get cat(){
        return 'set'
    }
    get player(){
        return false;
    }
    get inVoice(){
        return false;
    }
    get sameVoice(){
        return false;
    }
    async run(client,message,args,prefix){
        if(!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild) && !client.config.owners.includes(message.author.id)){
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | You are lacking permissions : Manage Guild`).setAuthor({name : `247` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        let data = await client.data.get(`${message.guild.id}-247`);
        if(!data) await client.data.set(`${message.guild.id}-247`,`disabled`);
        if(data === `disabled`){
            client.data.set(`${message.guild.id}-247`,`enabled`);
            client.data.set(`${message.guild.id}-text`,`${message.channel.id}`);
            client.data.set(`${message.guild.id}-voice`,`${message.member.voice.channelId}`);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Enabled 247 Mode`).setAuthor({name : `247` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        else if(data === `enabled`){
            client.data.set(`${message.guild.id}-247`,`disabled`);
            client.data.delete(`${message.guild.id}-text`);
            client.data.delete(`${message.guild.id}-voice`);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Disabled 247 Mode`).setAuthor({name : `247` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        else{
            client.data.set(`${message.guild.id}-247`,`disabled`);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Please try again running that command`).setAuthor({name : `247` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
    }
}
module.exports = twentyfourseven;