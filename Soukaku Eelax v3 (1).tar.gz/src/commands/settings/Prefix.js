const { PermissionsBitField, EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class Prefix extends AvonCommand{
    get name(){
        return 'setprefix'
    }
    get cat(){
        return 'set'
    }
    get vote(){
        return false;
    }
    get aliases(){
        return ['prefix','set-prefix']
    }
    async run(client,message,args,prefix){
        if(!args[0]){
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.author} | My Current Prefix is ${prefix}`).setAuthor({name : `Prefix` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        if(!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild) && !client.config.owners.includes(message.author.id)){
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | You are lacking permissions : Manage Guild`).setAuthor({name : `Prefix` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        if(args[0].length > 3)
        {
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Prefix` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setDescription(`${client.emoji.cross} | Can't set a prefix having more than 3 args`)]})
        }
        if(args[1])
        {
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | You cannot take space between args`).setAuthor({name : `Prefix` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        if(args[0] === client.config.prefix){
            client.data.delete(`${message.guild.id}-prefix`);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Just restted the guild prefix`).setAuthor({name : `Prefix` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        client.data.set(`${message.guild.id}-prefix`,args[0]);
        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} Guild prefix has been changed to ${args[0]}`).setAuthor({name : `Prefix` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
    }
}
module.exports = Prefix;