const AvonCommand = require("../../structures/avonCommand");

class Reload extends AvonCommand {
    get name() {
        return 'reload';
    }

    get aliases() {
        return ['rd'];
    }

    async run(client, message, args, prefix) {
        try {
            // Check if args array is defined and has at least one element
            if (!args || args.length === 0) {
                return message.channel.send(`Please provide a command name to reload, ${message.author}!`);
            }

            const commandName = args[0].toLowerCase(); // Convert to lower case here
            const command =
                client.commands.get(commandName) || // Use client.commands instead of message.client.commands
                client.commands.find(
                    cmd => cmd.aliases && cmd.aliases.includes(commandName)
                );

            if (!command) {
                return message.channel.send(`There is no command with name or alias \`${commandName}\`, ${message.author}!`);
            }

            delete require.cache[
                require.resolve(
                    `${process.cwd()}/src/commands/${command.cat}/${command.name}.js`
                )
            ];

            try {
                const newCommand = require(`${process.cwd()}/src/commands/${command.cat}/${command.name}.js`);
                client.commands.set(newCommand.name, newCommand);
                message.channel.send({
                    content: `Successfully reloaded command \`${newCommand.name}\``
                });
            } catch (error) {
                console.error(error);
                message.channel.send(
                    `There was an error while reloading command \`${command.name}\`:\n\`${error.message}\``
                );
            }
        } catch (e) {
            console.log(e);
        }
    }
}

module.exports = Reload;
