const AvonCommand = require("../../structures/avonCommand");
const { EmbedBuilder } = require(`discord.js`);
class China extends AvonCommand{
    get name(){
        return 'china'
    }
    get aliases(){
        return null;
    }
    get vote(){
        return false;
    }
    get inVoice(){
        return true;
    }
    get sameVoice(){
        return true;
    }
    get cat(){
        return 'filters'
    }
    get player(){
        return true;
    }
    async run(client,message,args,prefix,player){
        let db = player.data.get(`china`);
        if(!db || db === undefined || db === false){
            player.send({
                guildId : message.guild.id,
                op : 'filters',
                timescale : {
                    speed : 0.75,
                    pitch : 1.25,
                    rate : 1.15
                }
            });
            player.data.set(`china`,true);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Filters`, iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setDescription(`${client.emoji.tick} | Enabled the China filter of the player`).setTimestamp()]});
        }
        if(db === true)
        {
            player.send({
                guildId : message.guild.id,
                op : 'filters',
                timescale : {
                    speed : 1.0,
                    pitch : 1.0,
                    rate : 1.0
                }
            });
            player.data.set(`china`,false);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Filters`, iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setDescription(`${client.emoji.tick} | Disabled the China filter of the player`).setTimestamp()]});
        }
    }
}
module.exports = China;