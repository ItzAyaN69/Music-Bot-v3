const { EmbedBuilder } = require(`discord.js`);
const AvonCommand = require("../../structures/avonCommand");

class Chipmunk extends AvonCommand{
    get name(){
        return 'chipmunk';
    }
    get vote(){
        return false;
    }
    get inVoice(){
        return true;
    }
    get sameVoice(){
        return true;
    }
    get cat(){
        return 'filters';
    }
    get player(){
        return true;
    }
    async run(client,message,args,prefix,player){
        let data = player.data.get(`chip`)
        if(!data || data == false || data == undefined)
        {
            player.send({
                guildId : message.guild.id,
                op : 'filters',
                timescale : {
                    speed : 1.05,
                    pitch : 1.35,
                    rate : 1.25
                }
            });
            player.data.set(`chip`,true);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Filters`, iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setDescription(`${client.emoji.tick} | Enabled the Chipmunk filter of the player`).setTimestamp()]});
        }
        if(data == true){
            player.data.set(`chip`,false);
            player.send({
                guildId : message.guild.id,
                op : 'filters',
                timescale : {
                    speed : 1.0,
                    pitch : 1.0,
                    rate : 1.0
                }
            });
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Filters`, iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setDescription(`${client.emoji.tick} | Disabled the Chipmunk filter of the player`).setTimestamp()]});
        }
    }
}
module.exports = Chipmunk;