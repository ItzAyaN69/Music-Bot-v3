const { EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class Pause extends AvonCommand{
    get name(){
        return 'pause';
    }
    get aliases(){
        return ['roko','pau']
    }
    get player(){
        return true;
    }
    get cat(){
        return 'music'
    }
    get inVoice(){
        return true;
    }
    get sameVoice(){
        return true;
    }
    async run(client,message,args,prefix,player){
        if(player.paused){
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.comfig.color).setDescription(`${client.emoji.cross} | Player is already Paused`).setAuthor({name : `Pause` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        else{
            player.pause(true);
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Player is Paused`).setAuthor({name : `Pause` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
    }
}
module.exports = Pause;