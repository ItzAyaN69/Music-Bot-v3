const { EmbedBuilder } = require("discord.js");
const moment = require(`moment`);
require(`moment-duration-format`);
const Arisa = require("../../structures/avonCommand");

class Grab extends Arisa{

    get name(){

        return 'grab'

    }

    get player(){

        return true;

    }

    get cat(){

        return 'music'

    }

    get inVoice(){

        return true;

    }

    get sameVoice(){

        return true;

    }

    async run(client,message,args,prefix,player)

    {
        let url = player.queue.current.uri;

        if(url.includes("youtube.com"))

        {

            url = this.client.config.server

        }
        let track = player.queue.current
        
        let duration = moment.duration(player.queue.current.length).format("hh:mm:ss")
               let emb = new EmbedBuilder().setColor(this.client.config.color).setDescription(`${this.client.emoji.playing} ${this.client.emoji.arrow} [${player.queue.current.title}](${url})`).addFields([

            {name : `${this.client.emoji.author} __Author__` , value : `${this.client.emoji.arrow} ${player.queue.current.author}` , inline : true}, 

            {name : `${this.client.emoji.time} __Duration__`,value : `${this.client.emoji.arrow} ${moment.duration(player.queue.current.length).format("hh:mm:ss")}`,inline : true}

        ]).setAuthor({name : `Grabbed Song` , iconURL : this.client.user.displayAvatarURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: track.requester.displayAvatarURL({ dynamic: true })}).setTimestamp()

               if (track.thumbnail) {

            emb.setThumbnail(track.thumbnail);

        } else {

            emb.setThumbnail(this.client.user.displayAvatarURL());

            };
     

     message.author.send({ embeds : [emb] }).then(() => {

     message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Grabbed Song in Your __DM__'s`).setAuthor({name : `Grab` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})}).catch((err) => { message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Your __DM__'s are Currently Off. Turn Them On To Grab`).setAuthor({name : `Grab` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})})

    }

}
module.exports = Grab;