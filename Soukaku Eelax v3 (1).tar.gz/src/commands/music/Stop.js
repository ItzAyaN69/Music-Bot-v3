const { EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand")

class Stop extends AvonCommand{
    get name(){
        return 'stop';
    }
    get aliases(){
        return [''];
    }
    get player(){
        return true;
    }
    get cat(){
        return 'music'
    }
    get inVoice(){
        return true;
    }
    get sameVoice(){
        return true;
    }
    async run(client,message,args,prefix,player){
        player.destroy();
        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Destroyed the player`).setAuthor({name : `Stop` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
    }
}
module.exports = Stop;