const { EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class ClearQueue extends AvonCommand{
    get name(){
        return 'clearqueue'
    }
    get aliases(){
        return ['clear','cq']
    }
    get player(){
        return true;
    }
    get cat(){
        return 'music'
    }
    get inVoice(){
        return true
    }
    get sameVoice(){
        return true;
    }
    async run(client,message,args,prefix,player){
        player.queue.clear();
        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `ClearQueue` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setDescription(`${client.emoji.tick} | SuccessFully Cleared Songs from Queue`)]});
    }
}
module.exports = ClearQueue;