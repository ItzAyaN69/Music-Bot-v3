const { EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class Seek extends AvonCommand{
    get name(){
        return 'seek'
    }
    get aliases(){
        return ['']
    }
    get cat(){
        return 'music'
    }
    get player(){
        return true;
    }
    get inVoice(){
        return true;
    }
    get sameVoice(){
        return true;
    }
    async run(client,message,args,prefix,player){
        if(!args[0] || isNaN(args[0]))
        {
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Provide me a valid Seeksble number`).setAuthor({name : `Seek` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        if(!player.queue.current.isSeekable){
            return message.channel.send({embeds : [new EmbedBuilder().setDescription(`${client.emoji.cross} | The Track is not Seekable`).setAuthor({name : `Seek` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp().setColor(client.config.color)]})
        }
        player.seek(args[0]);
        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Seeked the track ${args[0]}s`).setAuthor({name : `Seek` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
    }
}
module.exports = Seek;