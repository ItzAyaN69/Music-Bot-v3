const { EmbedBuilder } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class Loop extends AvonCommand{
    get name(){
        return 'loop'
    }
    get aliases(){
        return ['repeat','lop']
    }
    get inVoice(){
        return true;
    }
    get cat(){
        return 'music'
    }
    get sameVoice(){
        return true;
    }
    get player(){
        return true;
    }
    async run(client,message,args,prefix,player){
        try{
            let mode = '';
            if(player.loop === `none`) mode = 'Off';
            if(player.loop === `track`) mode = `Track`;
            if(player.loop === `queue`) mode = 'Queue';
        if(!args[0])
        {
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Loop mode setled to ${mode} Use ${client.emoji.arrow} \`${prefix}loop <off/track/queue>\``).setAuthor({name : `Loop` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        let op = args[0].toLowerCase();
        if(op === `off`)
        {
            player.setLoop('none');
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Loop mode has been set to Off`).setAuthor({name : `Loop` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        if(op === `track`)
        {
            player.setLoop('track');
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Loop Mode has been set to Track`).setAuthor({name : `Loop` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        if(op === `queue`)
        {
            player.setLoop("queue");
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.tick} | Loop Mode has been set to Queue`).setAuthor({name : `Loop` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
        else{
            return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Use ${client.emoji.arrow} \`${prefix}loop <off/track/queue>\``).setAuthor({name : `Loop` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
        }
    } catch(e) {console.log(e)}
    }
}
module.exports = Loop;