const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const AvonCommand = require("../../structures/avonCommand");

class Connect extends AvonCommand {
    get name() {
        return 'connect';
    }
    get aliases() {
        return ['join', 'conn'];
    }
    get player() {
        return false;
    }
    get inVoice() {
        return true;
    }
    get cat() {
        return 'music';
    }
    get sameVoice() {
        return false;
    }
    async run(client, message, args, prefix) {
        let player = client.poru.players.get(message.guild.id);
        if (message.guild.members.me.voice && message.guild.members.me.voice.channel) {
            if (player) {
                return message.channel.send({
                    embeds: [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | I am already connected to ${message.guild.members.me.voice.channel}`).setAuthor({ name: `Connect`, iconURL: message.guild.iconURL() }).setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) }).setTimestamp()]
                })
            } else if (!player) {
                message.guild.members.me.voice.disconnect();

                if (message.guild.members.me.permissionsIn(message.member.voice.channel).has([PermissionsBitField.FLAGS.CONNECT, PermissionsBitField.FLAGS.SPEAK])) {
                    await client.poru.createPlayer({
                        guildId: message.guild.id,
                        textId: message.channel.id,
                        voiceId: message.member.voice.channel.id,
                        volume: 100,
                        deaf: true,
                        shardId: message.guild.shardId
                    });
                    return message.channel.send({
                        embeds: [new EmbedBuilder().setColor(client.config.color).setAuthor({ name: `Connect`, iconURL: message.guild.iconURL() }).setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) }).setTimestamp().setDescription(`${client.emoji.tick} | Connected to your Voice Channel`)]
                    })
                } else {
                    return message.channel.send({
                        embeds: [new EmbedBuilder().setColor(client.config.color).setAuthor({ name: `Connect`, iconURL: message.guild.iconURL() }).setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) }).setTimestamp().setDescription(`${client.emoji.cross} | Missing Connect or Speak permissions on your voice channel`)]
                    });
                }
            }
        } else {
            return message.channel.send({
                embeds: [new EmbedBuilder().setColor(client.config.color).setAuthor({ name: `Connect`, iconURL: message.guild.iconURL() }).setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) }).setTimestamp().setDescription(`${client.emoji.cross} | I am not in a voice channel`)]
            });
        }
    }
}
module.exports = Connect;
