const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const moment = require(`moment`);
const ArisaCommand = require("../../structures/avonCommand");

class Nowplaying extends ArisaCommand {
    get name() {
        return 'nowplaying'
    }
    get aliases() {
        return ['np']
    }
    get inVoice(){ 
        return true; 
    } 
    get player() { 
        return true;
        }
    get player() {
        return true;
    }
    get cat() {
        return 'music'
    }
    async run(client, message, args, prefix, player) {
        let url = player.queue.current.uri;

        if(url.includes("youtube.com"))

        {

            url = this.client.config.support

        }

        let track = player.queue.current
        const currentTime = moment.duration(player.position).asMinutes();
        const totalTime = moment.duration(player.queue.current.length).asMinutes();
        const progressBar = createProgressBar(currentTime, totalTime, 20); // You can adjust the progress bar length (e.g., 20).
       
         

           
        
        const em = new EmbedBuilder()
            .setDescription(`${this.client.emoji.playing} ${this.client.emoji.arrow} **[${player.queue.current.title}](${url})**`)
            .setColor(this.client.config.color)
        .addFields([
                { name: `${this.client.emoji.author} __Author__`, value: `${this.client.emoji.arrow} ${player.queue.current.author}`, inline: true },
                { name: `${this.client.emoji.users} __Requester__`, value: `${this.client.emoji.arrow} ${player.queue.current.requester}`, inline: true },
                { name: `${this.client.emoji.time} __Duration__`, value: `${moment.duration(player.position).format("hh:mm:ss")}/${moment.duration(player.queue.current.length).format("hh:mm:ss")}`, inline: true },
                { name: `<:progress:1221086987344285707> __Progress Bar__`, value: `${progressBar}`, inline: false },
            ]).setAuthor({name : `Now Playing` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()
        if (track.thumbnail) {

            em.setThumbnail(track.thumbnail);

        } else {

            em.setThumbnail(this.client.user.displayAvatarURL());

            }
            
        message.channel.send({ embeds: [em] });
    }
}

function createProgressBar(current, total, length) {
    const progress = current / total;
    const progressBar = `<:progress:1221086987344285707>`.repeat(Math.floor(progress * length)) + `<:progress:1221086987344285707>`.repeat(length - Math.floor(progress * length));
    return progressBar;
}

module.exports = Nowplaying;