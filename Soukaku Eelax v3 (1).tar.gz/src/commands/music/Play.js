const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");
const ms = require("ms");
const { KazagumoTrack } = require(`kazagumo`);
const AvonCommand = require(`../../structures/avonCommand`);
class Play extends AvonCommand{
    get name(){
        return 'play'
    }
    get aliases(){
        return ['p','play','start','search']
    }
    get cat(){
        return 'music'
    }
    get inVoice(){
        return true;
    }
    get sameVoice(){
        return true;
    }
    async run(client,message,args,prefix){
        try{
            if(!args[0]){
                return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Command Usage ${client.emoji.rightarrow} \`${prefix}play <name/song url>\``).setAuthor({name : `Play` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]})
            }
            let channel = message.member.voice.channel;
            var player = client.poru.players.get(message.guild.id);
            if(!player){
                player = await client.poru.createPlayer({
                    guildId : message.guild.id,
                    voiceId : channel.id,
                    textId : message.channel.id,
                    deaf : true,
                    volume : 100,
                    shardId : message.guild.shardId
                });
            }

            let query = args.join(" ");
            player.setTextChannel(message.channel.id);
            if(query.startsWith('https://'))
            {
                if(query.includes(`youtube`))
                {
                    return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | I don't resolve youtube links anymore due to Youtube's TOS Violation`).setAuthor({name : `Play` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]});
                }
                if(query.includes(`youtu.be`))
                {
                    return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | I don't resolve youtube links anymore due to Youtube's TOS Violation`).setAuthor({name : `Play` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]});
                }
                if(query.includes(`spotify`))
                {
                    try{
                    await client.lavasfy.requestToken();
                    let node = client.lavasfy.nodes.get('Avon');
                    let result = await node.load(query);
                    if(result.loadType === `LOAD_FAILED`)
                    {
                        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | Failed while Loading`).setAuthor({name : `Play` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()]});
                    }
                    if(result.loadType === `PLAYLIST_LOADED`)
                    {
                        let songs = [];
                        for(let i = 0; i < result.tracks.length; i++)
                        {
                            let convert = new KazagumoTrack(result.tracks[i],message.author);
                            songs.push(convert);
                        }
                        player.queue.add(songs);
                        if(!player.playing && !player.paused) player.play();
                        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Playlist to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** \`${result.tracks.length}\`\n **Songs from** *${result.playlistInfo.name}* \n ${client.emoji.users} **Requester** ${client.emoji.arrow} ${message.author} \n ${client.emoji.time} **Duration** ${ms(result.tracks.reduce((a,v) => a+v.info.length,0))}`).setTimestamp()]})
                    }
                    if(result.loadType === `TRACK_LOADED`|| result.loadType === `SEARCH_RESULT`)
                    {
                        let convertedTrack = new KazagumoTrack(result.tracks[0],message.author);
                        player.queue.add(convertedTrack);
                        if(!player.playing && !player.paused) player.play();
                        return message.channel.send({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Song to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** [${result.tracks[0].info.title}](${result.tracks[0].info.uri}) \n ${client.emoji.users} **Requester** ${message.author}`).setTimestamp()]});
                    }
                } catch(e) { console.log(e) }
                }
                else{
                    let result = await player.search(query , {requester : message.author});
                    if(!result.tracks.length)
                    {
                        return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.cross} | No Results were found`).setAuthor({name : `Play` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()],components : []});
                    }
                    if(result.type === `PLAYLIST`)
                    {
                        for(let track of result.tracks)
                        {
                            player.queue.add(track);
                            if(!player.playing && !player.paused) player.play();
                            return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Playlist To Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** \`${result.tracks.length}\` Songs from *${result.playlistName}* \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** \`${ms(result.playlistInfo.length)}\``).setTimestamp()],components : []});
                        }
                    }
                    else{
                        player.queue.add(result.tracks[0]);
                        if(!player.playing && !player.paused) player.play();
                        return interaction.update({components : [],embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Song to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** [${result.tracks[0].title}](${client.config.support}) \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** ${ms(result.tracks[0].length)}`).setTimestamp()]});
                    }
                }
            }

            let emb = new EmbedBuilder().setColor(client.config.color).setDescription(`${client.emoji.author} | Eelax Platform Search! \n> Select A Platform To Continue Music `).setAuthor({name : `Play` , iconURL : message.guild.iconURL()}).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp();
            let b1 = new ButtonBuilder().setStyle(ButtonStyle.Secondary).setLabel(`Youtube`).setCustomId(`def`);
            let b2 = new ButtonBuilder().setStyle(ButtonStyle.Success).setCustomId(`spoti`).setLabel(`Spotify`);
   
            let ro = new ActionRowBuilder().addComponents(b1,b2,);

            let msg = await message.channel.send({embeds : [emb] , components : [ro]});

            let co = await msg.createMessageComponentCollector({
                filter : (b) => {
                    if(b.user.id === message.author.id) return true;
                    else{
                        return b.reply({content : `${client.emoji.cross} | You are not the author of this command`,ephemeral : true});
                    }
                },
                time : 600000 * 5
            });

            co.on('collect',async(interaction) => {
                if(interaction.isButton())
                {
                    if(interaction.user.id !== message.author.id) return interaction.deferUpdate();
                    try{
                    if(interaction.customId === `def`)
                    {
                        let result = await player.search(query , {requester : message.author});
                        if(!result.tracks.length)
                        {
                            return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Play`,iconURL : message.guild.iconURL()}). setDescription(`${client.emoji.cross} | No results were found`).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()],components : []});
                        }
                        if(result.type === `PLAYLIST`)
                        {
                            for(let track of result.tracks)
                            {
                                player.queue.add(track);
                                if(!player.playing && !player.paused) player.play();
                                return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Playlist To Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** \`${result.tracks.length}\` Songs from *${result.playlistName}* \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** \`${ms(result.playlistInfo.length)}\``).setTimestamp()],components : []});
                            }
                        }
                        else{
                            player.queue.add(result.tracks[0]);
                            if(!player.playing && !player.paused) player.play();
                            return interaction.update({components : [],embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Song to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** [${result.tracks[0].title}](${client.config.support}) \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration**  ${ms(result.tracks[0].length)}`).setTimestamp()]});
                        }
                    }
                    if(interaction.customId === `spoti`)
                    {
                        let result = await player.search(query , {engine : `spotify`,requester : message.author});
                        if(!result.tracks.length)
                        {
                            return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Play`,iconURL : message.guild.iconURL()}). setDescription(`${client.emoji.cross} | No results were found`).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()],components : []});
                        }
                        if(result.type === `PLAYLIST`)
                        {
                            for(let track of result.tracks)
                            {
                                let tr = new KazagumoTrack(track.getRaw(),message.author);
                                player.queue.add(tr);
                                if(!player.playing && !player.paused) player.play();
                                return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Playlist To Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** \`${result.tracks.length}\` Songs from *${result.playlistName}* \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** \`${ms(result.playlistInfo.length)}\``).setTimestamp()],components : []});
                            }
                        }
                        else{
                            let re = new KazagumoTrack(result.tracks[0].getRaw(),message.author);
                            player.queue.add(re);
                            if(!player.playing && !player.paused) player.play();
                            return interaction.update({components : [],embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Song to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** [${result.tracks[0].title}](${client.config.support}) \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** ${ms(result.tracks[0].length)}`).setTimestamp()]});
                        }
                    }
                    if(interaction.customId === `deez`)
                    {
                        let result = await player.search(query , {engine : `deezer`,requester : message.author});
                        if(!result.tracks.length)
                        {
                            return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Play`,iconURL : message.guild.iconURL()}). setDescription(`${client.emoji.cross} | No results were found`).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()],components : []});
                        }
                        if(result.type === `PLAYLIST`)
                        {
                            for(let track of result.tracks)
                            {
                                player.queue.add(track);
                                if(!player.playing && !player.paused) player.play();
                                return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Playlist To Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** \`${result.tracks.length}\` Songs from *${result.playlistName}* \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** \`${ms(result.playlistInfo.length)}\``).setTimestamp()],components : []});
                            }
                        }
                        else{
                            player.queue.add(result.tracks[0]);
                            if(!player.playing && !player.paused) player.play();
                            return interaction.update({components : [],embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Song to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** [${result.tracks[0].title}](${client.config.server}) \n ${client.emoji.users} **Requester** ${message.author} \n ${client.emoji.time} **Duration** ${ms(result.tracks[0].length)}`).setTimestamp()]});
                        }
                    }
                    if(interaction.customId === `sc`)
                    {
                        let result = await player.search(query , {engine : `soundcloud`,requester : message.author});
                        if(!result.tracks.length)
                        {
                            return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Play`,iconURL : message.guild.iconURL()}). setDescription(`${client.emoji.cross} | No results were found`).setFooter({text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true })}).setTimestamp()],components : []});
                        }
                        if(result.type === `PLAYLIST`)
                        {
                            for(let track of result.tracks)
                            {
                                player.queue.add(track);
                                if(!player.playing && !player.paused) player.play();
                                return interaction.update({embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Playlist To Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** \`${result.tracks.length}\` Songs from *${result.playlistName}* \n ${client.emoji.users} **Requester** <:point:1206176814926397490> ${message.author} \n ${client.emoji.time} **Duration** <:point:1206176814926397490> \`${ms(result.playlistInfo.length)}\``).setTimestamp()],components : []});
                            }
                        }
                        else{
                            player.queue.add(result.tracks[0]);
                            if(!player.playing && !player.paused) player.play();
                            return interaction.update({components : [],embeds : [new EmbedBuilder().setColor(client.config.color).setAuthor({name : `Added Song to Queue`,iconURL : message.guild.iconURL()}).setDescription(`${client.emoji.queue} **Added** [${result.tracks[0].title}](${client.config.server}) \n ${client.emoji.users} **Requester** <:point:1206176814926397490> ${message.author} \n ${client.emoji.time} **Duration** <:point:1206176814926397490> ${ms(result.tracks[0].length)}`).setTimestamp()]});
                        }
                    }
                } catch(e) { }
                }
            });
            co.on('end',async() => {
                return;
            })
        } catch(e) { }
    }
}
module.exports = Play;