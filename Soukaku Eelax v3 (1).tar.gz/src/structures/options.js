const shoukakuOptions = {
    moveOnDisconnect: true,
    resumable: true,
    resumableTimeout: 30,
    reconnectTries: 3,
    restTimeout: 10000
};