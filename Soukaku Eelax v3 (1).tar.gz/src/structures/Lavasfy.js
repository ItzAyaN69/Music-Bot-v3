const { LavasfyClient } = require("lavasfy");
const config = require(`../../config.json`);
class Lavasfy extends LavasfyClient{
    constructor(client){
        super({
            clientID : config.spotifyId,
            clientSecret : config.spotifySecret,
            playlistLoadLimit : 200,
            audioOnlyResults : true,
            autoResolve : true,
            useSpotifyMetadata : true
        },[
            {
                id : "Avon",
                host : "qc-01.micium-hosting.com",
                port : 3873,
                password : "Astoria123",
                secure : false
            }
        ]);
    }
}
module.exports = Lavasfy;