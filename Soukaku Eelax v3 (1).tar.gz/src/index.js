const Avon = require("./structures/avonClient.js");
const client = new Avon();
module.exports = client;